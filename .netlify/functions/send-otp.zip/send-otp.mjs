
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/send-otp.mjs
import { createHmac, randomInt } from "node:crypto";
var CODE_TTL_MS = 5 * 60 * 1e3;
function normalizePhone(phone) {
  return String(phone ?? "").replace(/[^\d+]/g, "");
}
function signCode(phone, code, expiresAt, secret) {
  return createHmac("sha256", secret).update(`${phone}|${code}|${expiresAt}`).digest("base64url");
}
async function handler(request) {
  if (request.method !== "POST") {
    return Response.json({ error: "Method not allowed." }, { status: 405 });
  }
  const secret = process.env.OTP_SIGNING_SECRET;
  const apiKey = process.env.SEMAPHORE_API_KEY;
  const senderName = process.env.SEMAPHORE_SENDER_NAME ?? "";
  if (!secret || !apiKey) {
    return Response.json(
      { error: "OTP sending is not configured on the server yet." },
      { status: 503 }
    );
  }
  const body = await request.json().catch(() => ({}));
  const phone = normalizePhone(body.phone);
  if (!phone) return Response.json({ error: "Phone number is required." }, { status: 400 });
  const code = String(randomInt(1e3, 1e4));
  const expiresAt = Date.now() + CODE_TTL_MS;
  const message = `Your TodaRide verification code is ${code}. It expires in 5 minutes.`;
  const res = await fetch("https://api.semaphore.co/api/v4/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      apikey: apiKey,
      number: phone,
      message,
      ...senderName ? { sendername: senderName } : {}
    })
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const detail = data && (data.message || JSON.stringify(data)) || res.statusText;
    return Response.json({ error: `Failed to send SMS: ${detail}` }, { status: 502 });
  }
  return Response.json({
    ok: true,
    // The client hands these back on verify. Neither reveals the code.
    token: signCode(phone, code, expiresAt, secret),
    expiresAt
  });
}
export {
  handler as default,
  signCode
};
