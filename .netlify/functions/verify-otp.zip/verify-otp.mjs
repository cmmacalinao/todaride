
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/verify-otp.mjs
import { createHmac, timingSafeEqual } from "node:crypto";
function normalizePhone(phone) {
  return String(phone ?? "").replace(/[^\d+]/g, "");
}
function signCode(phone, code, expiresAt, secret) {
  return createHmac("sha256", secret).update(`${phone}|${code}|${expiresAt}`).digest("base64url");
}
function sameSignature(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}
async function handler(request) {
  if (request.method !== "POST") {
    return Response.json({ error: "Method not allowed." }, { status: 405 });
  }
  const secret = process.env.OTP_SIGNING_SECRET;
  if (!secret) {
    return Response.json({ error: "OTP verification is not configured on the server yet." }, { status: 503 });
  }
  const body = await request.json().catch(() => ({}));
  const phone = normalizePhone(body.phone);
  const code = String(body.code ?? "").trim();
  const token = String(body.token ?? "");
  const expiresAt = Number(body.expiresAt ?? 0);
  if (!phone || !code) return Response.json({ error: "Phone number and code are required." }, { status: 400 });
  if (!token || !expiresAt) {
    return Response.json({ error: "No code was sent to this number \u2014 send one first." }, { status: 400 });
  }
  if (Date.now() > expiresAt) {
    return Response.json({ error: "Code expired \u2014 request a new one." }, { status: 400 });
  }
  if (!sameSignature(token, signCode(phone, code, expiresAt, secret))) {
    return Response.json({ error: "Incorrect code." }, { status: 400 });
  }
  return Response.json({ ok: true });
}
export {
  handler as default
};
